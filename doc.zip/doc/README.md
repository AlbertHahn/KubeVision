# Bachelorarbeit
Die ausgeschriebene Form meiner Abschlussarbeit als LateX und PDF-File.

## Quellen

### Bücher
#### Microservices for the Enterprise
https://link.springer.com/book/10.1007%2F978-1-4842-3858-5

#### Modulare Softwarearchitektur
https://www.hanser-elibrary.com/doi/book/10.3139/9783446465343

#### Deploy Machine Learning Models to Production
https://link.springer.com/book/10.1007%2F978-1-4842-6546-8

### Publikationen
#### Microservice Architecture for Cognitive Networks
https://ieeexplore.ieee.org/abstract/document/9262617

#### Scalability Assessment of Microservice Architecture Deployment Configurations: A Domain-based Approach Leveraging Operational Profiles and Load Tests
https://www.sciencedirect.com/science/article/pii/S016412122030042X